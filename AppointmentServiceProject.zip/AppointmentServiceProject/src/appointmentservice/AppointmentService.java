package appointmentservice;

import java.util.HashMap;

public class AppointmentService {
    private HashMap<String, Appointment> appointments = new HashMap<>();

    // Add a new appointment (must have unique ID)
    public void addAppointment(Appointment appointment) {
        if (appointment == null || appointments.containsKey(appointment.getAppointmentId())) {
            throw new IllegalArgumentException("Appointment ID must be unique and not null");
        }
        appointments.put(appointment.getAppointmentId(), appointment);
    }

    // Delete an appointment by ID
    public void deleteAppointment(String appointmentId) {
        if (!appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Appointment ID not found");
        }
        appointments.remove(appointmentId);
    }

    // Optional getter for testing
    public Appointment getAppointment(String appointmentId) {
        return appointments.get(appointmentId);
    }
}
