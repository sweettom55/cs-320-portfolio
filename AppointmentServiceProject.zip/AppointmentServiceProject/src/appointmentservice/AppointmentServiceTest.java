package appointmentservice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Calendar;
import java.util.Date;

public class AppointmentServiceTest {

    private AppointmentService service;

    @BeforeEach
    public void setup() {
        service = new AppointmentService();
    }

    // Helper to get a future date
    private Date getFutureDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 1);
        return cal.getTime();
    }

    @Test
    public void testAddAppointment() {
        Appointment appt = new Appointment("001", getFutureDate(), "Dental Cleaning");
        service.addAppointment(appt);
        assertEquals(appt, service.getAppointment("001"));
    }

    @Test
    public void testAddDuplicateIdThrowsException() {
        Appointment appt1 = new Appointment("001", getFutureDate(), "Meeting");
        Appointment appt2 = new Appointment("001", getFutureDate(), "Follow-up");
        service.addAppointment(appt1);
        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(appt2);
        });
    }

    @Test
    public void testDeleteAppointment() {
        Appointment appt = new Appointment("002", getFutureDate(), "Interview");
        service.addAppointment(appt);
        service.deleteAppointment("002");
        assertNull(service.getAppointment("002"));
    }

    @Test
    public void testDeleteNonexistentAppointmentThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment("999");
        });
    }
}
