package appointmentservice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.util.Calendar;
import java.util.Date;

public class AppointmentTest {

    // Helper to get a future date
    private Date getFutureDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 1);
        return cal.getTime();
    }

    // Helper to get a past date
    private Date getPastDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -1);
        return cal.getTime();
    }

    @Test
    public void testValidAppointmentCreation() {
        Date futureDate = getFutureDate();
        Appointment appt = new Appointment("123", futureDate, "Doctor visit");
        assertEquals("123", appt.getAppointmentId());
        assertEquals(futureDate, appt.getAppointmentDate());
        assertEquals("Doctor visit", appt.getDescription());
    }

    @Test
    public void testAppointmentIdTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", getFutureDate(), "Test");
        });
    }

    @Test
    public void testAppointmentDateInPast() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", getPastDate(), "Test");
        });
    }

    @Test
    public void testDescriptionTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", getFutureDate(), "This description is definitely more than fifty characters long.");
        });
    }

    @Test
    public void testSetDescriptionValid() {
        Appointment appt = new Appointment("123", getFutureDate(), "Initial description");
        appt.setDescription("Updated description");
        assertEquals("Updated description", appt.getDescription());
    }

    @Test
    public void testSetDescriptionInvalid() {
        Appointment appt = new Appointment("123", getFutureDate(), "Initial");
        assertThrows(IllegalArgumentException.class, () -> {
            appt.setDescription(null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            appt.setDescription("This description is definitely more than fifty characters long.");
        });
    }
}
