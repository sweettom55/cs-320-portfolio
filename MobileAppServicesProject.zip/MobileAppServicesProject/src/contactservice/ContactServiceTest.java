package contactservice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    private ContactService service;

    @BeforeEach
    public void setup() {
        service = new ContactService();
    }

    @Test
    public void testAddContact() {
        Contact contact = new Contact("001", "John", "Doe", "1234567890", "123 Main St");
        service.addContact(contact);
        assertEquals(contact, service.getContact("001"));
    }

    @Test
    public void testAddDuplicateIdThrowsException() {
        Contact contact1 = new Contact("001", "John", "Doe", "1234567890", "123 Main St");
        Contact contact2 = new Contact("001", "Jane", "Smith", "0987654321", "456 Elm St");
        service.addContact(contact1);
        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(contact2);
        });
    }

    @Test
    public void testDeleteContact() {
        Contact contact = new Contact("002", "Anna", "Jones", "1112223333", "789 Oak St");
        service.addContact(contact);
        service.deleteContact("002");
        assertNull(service.getContact("002"));
    }

    @Test
    public void testUpdateContactFields() {
        Contact contact = new Contact("003", "Chris", "Taylor", "2223334444", "456 Birch Rd");
        service.addContact(contact);
        service.updateFirstName("003", "Alex");
        service.updateLastName("003", "Brown");
        service.updatePhone("003", "5556667777");
        service.updateAddress("003", "999 Pine Ave");

        Contact updated = service.getContact("003");
        assertEquals("Alex", updated.getFirstName());
        assertEquals("Brown", updated.getLastName());
        assertEquals("5556667777", updated.getPhone());
        assertEquals("999 Pine Ave", updated.getAddress());
    }

    @Test
    public void testUpdateNonexistentContactThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateFirstName("999", "Ghost");
        });
    }
}
