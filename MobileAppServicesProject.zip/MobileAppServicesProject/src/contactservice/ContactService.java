package contactservice;

import java.util.HashMap;

public class ContactService {
    private HashMap<String, Contact> contacts = new HashMap<>();

    // Add a new contact (must have unique ID)
    public void addContact(Contact contact) {
        if (contact == null || contacts.containsKey(contact.getContactId())) {
            throw new IllegalArgumentException("Contact ID must be unique and not null");
        }
        contacts.put(contact.getContactId(), contact);
    }

    // Delete a contact by ID
    public void deleteContact(String contactId) {
        if (!contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact ID not found");
        }
        contacts.remove(contactId);
    }

    // Update fields individually
    public void updateFirstName(String contactId, String newFirstName) {
        Contact contact = contacts.get(contactId);
        if (contact != null) {
            contact.setFirstName(newFirstName);
        } else {
            throw new IllegalArgumentException("Contact ID not found");
        }
    }

    public void updateLastName(String contactId, String newLastName) {
        Contact contact = contacts.get(contactId);
        if (contact != null) {
            contact.setLastName(newLastName);
        } else {
            throw new IllegalArgumentException("Contact ID not found");
        }
    }

    public void updatePhone(String contactId, String newPhone) {
        Contact contact = contacts.get(contactId);
        if (contact != null) {
            contact.setPhone(newPhone);
        } else {
            throw new IllegalArgumentException("Contact ID not found");
        }
    }

    public void updateAddress(String contactId, String newAddress) {
        Contact contact = contacts.get(contactId);
        if (contact != null) {
            contact.setAddress(newAddress);
        } else {
            throw new IllegalArgumentException("Contact ID not found");
        }
    }

    // Optional getter for unit tests
    public Contact getContact(String contactId) {
        return contacts.get(contactId);
    }
}
