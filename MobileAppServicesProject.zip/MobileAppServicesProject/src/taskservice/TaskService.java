package taskservice;

import java.util.HashMap;

public class TaskService {
    private HashMap<String, Task> tasks = new HashMap<>();

    // Add a new task (must have unique ID)
    public void addTask(Task task) {
        if (task == null || tasks.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("Task ID must be unique and not null");
        }
        tasks.put(task.getTaskId(), task);
    }

    // Delete a task by ID
    public void deleteTask(String taskId) {
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID not found");
        }
        tasks.remove(taskId);
    }

    // Update name
    public void updateName(String taskId, String newName) {
        Task task = tasks.get(taskId);
        if (task != null) {
            task.setName(newName);
        } else {
            throw new IllegalArgumentException("Task ID not found");
        }
    }

    // Update description
    public void updateDescription(String taskId, String newDescription) {
        Task task = tasks.get(taskId);
        if (task != null) {
            task.setDescription(newDescription);
        } else {
            throw new IllegalArgumentException("Task ID not found");
        }
    }

    // Optional getter for testing
    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }
}
