package taskservice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {

    private TaskService service;

    @BeforeEach
    public void setup() {
        service = new TaskService();
    }

    @Test
    public void testAddTask() {
        Task task = new Task("001", "Task 1", "Description 1");
        service.addTask(task);
        assertEquals(task, service.getTask("001"));
    }

    @Test
    public void testAddDuplicateTaskIdThrowsException() {
        Task task1 = new Task("001", "Task 1", "Description 1");
        Task task2 = new Task("001", "Task 2", "Description 2");
        service.addTask(task1);
        assertThrows(IllegalArgumentException.class, () -> {
            service.addTask(task2);
        });
    }

    @Test
    public void testDeleteTask() {
        Task task = new Task("002", "Task 2", "To be deleted");
        service.addTask(task);
        service.deleteTask("002");
        assertNull(service.getTask("002"));
    }

    @Test
    public void testUpdateNameAndDescription() {
        Task task = new Task("003", "Original Name", "Original Desc");
        service.addTask(task);
        service.updateName("003", "Updated Name");
        service.updateDescription("003", "Updated Desc");

        Task updated = service.getTask("003");
        assertEquals("Updated Name", updated.getName());
        assertEquals("Updated Desc", updated.getDescription());
    }

    @Test
    public void testUpdateNonexistentTaskThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateName("999", "No Task");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateDescription("999", "No Task Desc");
        });
    }
}

