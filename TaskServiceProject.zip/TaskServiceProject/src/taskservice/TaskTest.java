package taskservice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    public void testValidTaskCreation() {
        Task task = new Task("123", "Grocery List", "Buy milk, eggs, and bread");
        assertEquals("123", task.getTaskId());
        assertEquals("Grocery List", task.getName());
        assertEquals("Buy milk, eggs, and bread", task.getDescription());
    }

    @Test
    public void testTaskIdTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Name", "Description");
        });
    }

    @Test
    public void testNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("001", "ThisNameIsWayTooLongToBeValid", "Description");
        });
    }

    @Test
    public void testDescriptionTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("001", "Task Name", "This description is definitely longer than fifty characters and should throw.");
        });
    }

    @Test
    public void testSettersWork() {
        Task task = new Task("123", "Task", "Do something");
        task.setName("Updated Task");
        task.setDescription("This is the updated description.");
        assertEquals("Updated Task", task.getName());
        assertEquals("This is the updated description.", task.getDescription());
    }
}
